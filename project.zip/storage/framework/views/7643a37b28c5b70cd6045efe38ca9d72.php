<?php $__env->startSection('content'); ?>
  <main id="main">

    <!-- ======= Hero Section ======= -->
    <?php echo $__env->make('components.Home.Jumbotron', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ======= About Section ======= -->
    <?php echo $__env->make('components.Home.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ======= Resume Section ======= -->
    <?php echo $__env->make('components.Home.resume', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ======= Portfolio Section ======= -->
    <?php echo $__env->make('components.Home.portofolio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ======= Contact Section ======= -->
    <?php echo $__env->make('components.Home.contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webprofile\resources\views/welcome.blade.php ENDPATH**/ ?>